/*Header file for Queue*/
#define size 10

void joinQ(int item);
int leaveQ();
int isEmpty();
int isFull();
int SIZE();

