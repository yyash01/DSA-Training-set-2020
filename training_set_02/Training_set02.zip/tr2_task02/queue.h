/*Header file for Queue*/
#define size 100001

void joinQ(int item);
int leaveQ();
int isEmpty();
int isFull();
